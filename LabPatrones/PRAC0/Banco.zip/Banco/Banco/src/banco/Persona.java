package banco;

public class Persona {

    private String direccion;
    private String DNI;
    private String nombre;
    private long telefono;

    public Persona(String direccion, String DNI, String nombre, long telefono) {
        this.direccion = direccion;
        this.DNI = DNI;
        this.nombre = nombre;
        this.telefono = telefono;
    }

}
