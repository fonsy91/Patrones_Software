package banco;

public class Sucursal {

    private String direccion;
    private String id;

    public Sucursal(String direccion, String id) {
        this.direccion = direccion;
        this.id = id;
    }

}
