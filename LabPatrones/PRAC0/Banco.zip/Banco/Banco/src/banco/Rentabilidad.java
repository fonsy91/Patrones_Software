package banco;

public interface Rentabilidad {

    public double calculaRentabilidad();

}
