package banco;

public class Cliente extends Persona {

    public Cliente(String direccion, String DNI, String nombre, long telefono) {
        super(direccion, DNI, nombre, telefono);
    }

}
