package universidad;

public class PDI extends Personal {

    private String _departamento;
    private String _area;

    public PDI(Handler identificador, String departamento, String area) throws BadFormatException {
        super(identificador);
        _departamento = departamento;
        _area = area;
    }

    public String getDepartamento() {
        return _departamento;
    }

    public String getArea() {
        return _area;
    }

    @Override
    public String generarNomina() {
        FactoriaNominas factoria = new FactoriaNominas();
        Nomina nomina = factoria.getNomina(0);
        this.setNomina(nomina);
        return "Generada nomina de PDI: " + super.getIdentificador() + "\n" + nomina.toString();
    }

    @Override
    public boolean modificar(IntPersonal otro) {
        boolean ok;

        ok = false;
        try {
            if (super.getIdentificador().compareTo(otro.getIdentificador()) == 0) {
                _departamento = ((PDI) otro).getDepartamento();
                _area = ((PDI) otro).getArea();
                ok = true;
            }
        } catch (ClassCastException e) {
            ok = false;
        }
        return ok;
    }

    @Override
    public String toString() {
        return super.toString()+ "#PDI{" + "_departamento=" + _departamento + ", _area=" + _area + '}';
    }

}
