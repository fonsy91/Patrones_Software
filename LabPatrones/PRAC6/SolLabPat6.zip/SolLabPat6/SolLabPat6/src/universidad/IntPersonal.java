package universidad;

public interface IntPersonal {

    public Handler getIdentificador();

    public String generarNomina();

    public Nomina getNomina();

    public boolean modificar(IntPersonal otro);

    @Override
    public String toString();

}
