package universidad;

import java.util.Random;

public class FactoriaNominas {

    private static final int PDI = 0;
    private static final int PAS = 1;
    private static final int BEC = 2;
    private final NominaBecario nb = new NominaBecario(500, 5);

    public Nomina getNomina(int tipo) {
        Random rand = new Random();
        switch (tipo) {
            case PDI:
                return (new NominaPDI(rand.nextInt(1001) + 1000, 25, rand.nextInt(501)));
            case PAS:
                return (new NominaPAS(rand.nextInt(501) + 1000, 15, rand.nextInt(301)));
            case BEC:
                try {
                    return (Nomina) nb.clone();
                } catch (CloneNotSupportedException c) {
                    return new NominaBecario(0, 0);
                }
            default:
                return new NominaBecario(0, 0);
        }
    }
}
