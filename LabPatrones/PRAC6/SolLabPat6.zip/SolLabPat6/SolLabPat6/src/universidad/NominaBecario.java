package universidad;

public class NominaBecario extends Nomina implements Cloneable {

    public NominaBecario(int sueldo, int irpf) {
        super(sueldo, irpf);
    }

    @Override
    public int sueldoNeto() {
        int total = super.getSueldo();
        int retencion = Math.round(total * ((float) super.getIrpf() / 100));
        return total - retencion;
    }

    @Override
    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }

    @Override
    public String toString() {
        return "NominaPAS:" + "\nSueldo: " + super.getSueldo()
                + "\n IRPF: " + super.getIrpf()
                + "\n Sueldo Neto: " + sueldoNeto();
    }

}
