package universidad;

public abstract class Nomina {

    private int sueldo;    
    private int irpf;

    public Nomina(int sueldo, int irpf) {
        this.sueldo = sueldo;        
        this.irpf = irpf;
    }    
    
    public int getSueldo() {
        return sueldo;
    }

    public void setSueldo(int sueldo) {
        this.sueldo = sueldo;
    }
    
    public int getIrpf() {
        return irpf;
    }

    public void setIrpf(int irpf) {
        this.irpf = irpf;
    }
    
    public abstract int sueldoNeto();   

    @Override
    public String toString() {
        return "Nomina{" + "sueldo=" + sueldo + ", irpf=" + irpf + '}';
    }   
}
