package universidad;

public class NominaPDI extends Nomina {
    
    private int complementoInvestigacion;

    public NominaPDI(int sueldo, int irpf, int complementoInvestigacion) {
        super(sueldo, irpf);
        this.complementoInvestigacion = complementoInvestigacion;
    }
    
    @Override
    public int sueldoNeto() {
        int total = super.getSueldo() + this.complementoInvestigacion;
        int retencion = Math.round(total*((float)super.getIrpf()/100));
        System.out.println("retencion: " + retencion);
        return total - retencion;
    }

    @Override
    public String toString() {
        return "NominaPDI:" + "\nSueldo: " + super.getSueldo()                  
                + "\nComplemento Investigacion: " + this.complementoInvestigacion  
                + "\n IRPF: " + super.getIrpf()
                + "\n Sueldo Neto: " + sueldoNeto();
    }
    
}
