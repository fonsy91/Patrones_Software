package universidad;

class PAS extends Personal {

    private String _seccion;
    private String _cargo;

    public PAS(Handler identificador, String seccion, String cargo) throws BadFormatException {
        super(identificador);
        _seccion = seccion;
        _cargo = cargo;
    }

    public String getSeccion() {
        return _seccion;
    }

    public String getCargo() {
        return _cargo;
    }

    @Override
    public String generarNomina() {
        FactoriaNominas factoria = new FactoriaNominas();
        Nomina nomina = factoria.getNomina(1);
        this.setNomina(nomina);
        return "Generada nomina de PAS: " + super.getIdentificador() + "\n" + nomina.toString();
    }

    @Override
    public boolean modificar(IntPersonal otro) {
        boolean ok;

        ok = false;
        try {
            if (super.getIdentificador().compareTo(otro.getIdentificador()) == 0) {
                _seccion = ((PAS) otro).getSeccion();
                _cargo = ((PAS) otro).getCargo();
                ok = true;
            }
        } catch (ClassCastException e) {
            ok = false;
        }
        return ok;
    }

    @Override
    public String toString() {
        return super.toString()+ "#PAS{" + "_seccion=" + _seccion + ", _cargo=" + _cargo + '}';
    }
}
