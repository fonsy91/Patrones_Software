package universidad.bridge;

import java.util.ArrayList;
import universidad.IntPersonal;
import universidad.Nomina;

/**
 * Informe resumido en formato texto con el total de todas las nóminas.
 */
public class InformeTotalNominaTexto implements GeneradorInformesImp {

    @Override
    public String generaInforme(ArrayList<IntPersonal> personal) {
        StringBuilder stringBuilder = new StringBuilder();
        double total = 0;
        stringBuilder.append("totalNominas\n");
        for (IntPersonal persona : personal) {
            Nomina nomina = persona.getNomina();
            if (nomina != null) {
                total = total + nomina.getSueldo();
            }

        }
        stringBuilder.append(total);
        return stringBuilder.toString();
    }
}
