package universidad.bridge;

import java.util.ArrayList;
import universidad.IntPersonal;
import universidad.Nomina;

/**
 * Informe detallado en formato texto con 3 columnas (identificador, sueldo, irpf) separadas por punto y coma. 
 */
public class InformeDetalleNominaTexto implements GeneradorInformesImp {

    @Override
    public String generaInforme(ArrayList<IntPersonal> personal) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("identificador;sueldo;irpf\n");
        for (IntPersonal persona : personal) {
            Nomina nomina = persona.getNomina();
            if (nomina != null) {
                stringBuilder.append(persona.getIdentificador());
                stringBuilder.append(";");
                stringBuilder.append(nomina.getSueldo());
                stringBuilder.append(";");
                stringBuilder.append(nomina.getIrpf());
                stringBuilder.append("\n");
            }
        }
              
        return stringBuilder.toString();
    }
}
