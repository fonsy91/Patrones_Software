package universidad.bridge;

import java.util.ArrayList;
import universidad.IntPersonal;

/**
 * Implementador: define la interfaz de las clases de implementación. 
 */
public interface GeneradorInformesImp {
    public String generaInforme(ArrayList<IntPersonal> personal);
}
