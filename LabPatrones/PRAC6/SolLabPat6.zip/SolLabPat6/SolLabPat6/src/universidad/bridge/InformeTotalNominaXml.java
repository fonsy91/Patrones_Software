package universidad.bridge;

import java.util.ArrayList;
import universidad.IntPersonal;
import universidad.Nomina;

/**
 * Informe resumido en formato texto con el total de todas las nóminas en XML.
 */
public class InformeTotalNominaXml implements GeneradorInformesImp {

    @Override
    public String generaInforme(ArrayList<IntPersonal> personal) {
        StringBuilder stringBuilder = new StringBuilder();
        double total = 0;
        stringBuilder.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
        stringBuilder.append("<totalNominas>\n");
        for (IntPersonal persona : personal) {
            Nomina nomina = persona.getNomina();
            if (nomina != null) {
                total = total + nomina.getSueldo();
            }
        }
        stringBuilder.append("\t<total>");
        stringBuilder.append(total);
        stringBuilder.append("</total>\n");
        stringBuilder.append("</totalNominas>\n");
        return stringBuilder.toString();
    }
}
