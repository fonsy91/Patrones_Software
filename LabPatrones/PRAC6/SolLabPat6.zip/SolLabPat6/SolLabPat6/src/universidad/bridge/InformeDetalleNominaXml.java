package universidad.bridge;

import java.util.ArrayList;
import universidad.IntPersonal;
import universidad.Nomina;

/**
 * Informe detallado en formato XML
 */
public class InformeDetalleNominaXml implements GeneradorInformesImp {

    @Override
    public String generaInforme(ArrayList<IntPersonal> personal) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
        stringBuilder.append("<nominas>\n");
        for (IntPersonal persona : personal) {
            Nomina nomina = persona.getNomina();
            if (nomina != null) {
                stringBuilder.append("\t<nomina>\n");
                stringBuilder.append("\t\t<identificador>");
                stringBuilder.append(persona.getIdentificador());
                stringBuilder.append("</identificador>\n");
                stringBuilder.append("\t\t<sueldo>");
                stringBuilder.append(nomina.getSueldo());
                stringBuilder.append("</sueldo>\n");
                stringBuilder.append("\t\t<irpf>");
                stringBuilder.append(nomina.getIrpf());
                stringBuilder.append("</irpf>\n");
                stringBuilder.append("\t</nomina>\n");
            }
        }
        stringBuilder.append("</nominas>\n");
        return stringBuilder.toString();
    }
}
