package universidad;

public class Becario extends Personal {

    private String _proyecto;

    public Becario(Handler _identificador, String _proyecto) throws BadFormatException {
        super(_identificador);
        this._proyecto = _proyecto;
    }

    public String getProyecto() {
        return _proyecto;
    }

    public void setProyecto(String _proyecto) {
        this._proyecto = _proyecto;
    }

    @Override
    public boolean modificar(IntPersonal otro) {
        boolean ok;

        ok = false;
        try {
            if (super.getIdentificador().compareTo(otro.getIdentificador()) == 0) {
                _proyecto = ((Becario) otro).getProyecto();
                ok = true;
            }
        } catch (ClassCastException e) {
            ok = false;
        }
        return ok;
    }

    @Override
    public String generarNomina() {
        FactoriaNominas factoria = new FactoriaNominas();
        Nomina nomina = factoria.getNomina(2);
        this.setNomina(nomina);
        return "Generada nomina de Becario: " + super.getIdentificador() + "\n" + nomina.toString();
    }

    @Override
    public String toString() {
        return super.toString() + "#Becario{" + "_proyecto=" + _proyecto + '}';
    }

}
