package universidad;

public class NominaPAS extends Nomina {
    
    private int complementoProductividad;

    public NominaPAS(int sueldo, int irpf, int complementoProductividad) {
        super(sueldo, irpf);
        this.complementoProductividad = complementoProductividad;
    }
    
    @Override
    public int sueldoNeto() {
        int total = super.getSueldo() + this.complementoProductividad;
        int retencion = Math.round(total*((float)super.getIrpf()/100));        
        return total - retencion;
    }
    
    @Override
    public String toString() {
        return "NominaPAS:" + "\nSueldo: " + super.getSueldo()                  
                + "\nComplemento Productividad: " + this.complementoProductividad  
                + "\n IRPF: " + super.getIrpf()
                + "\n Sueldo Neto: " + sueldoNeto();
    }
    
}
