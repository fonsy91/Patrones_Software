package universidad;

public class BadFormatException extends Exception {
    public BadFormatException() {
        super("Error de formato.");
    }
}
