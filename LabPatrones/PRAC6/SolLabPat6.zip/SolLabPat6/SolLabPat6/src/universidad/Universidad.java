package universidad;

import java.util.ArrayList;

public class Universidad {

    private String _nombre;
    private ArrayList<IntPersonal> _personal;

    public Universidad(String nombre) {
        _nombre = nombre;
        _personal = new ArrayList();
    }

    public String getNombre() {
        return _nombre;
    }

    public ArrayList<IntPersonal> getPersonal() {
        return _personal;
    }

    public boolean contratar(IntPersonal persona) {
        return _personal.add(persona);
    }

    public boolean jubilar(Handler identificador) {
        IntPersonal persona;
        boolean ok;
        
        persona = buscar(identificador);
        if (persona != null) {
            ok = _personal.remove(persona);
        } else {
            ok = false;
        }
        return ok;
    }

    public IntPersonal buscar(Handler identificador) {
        for (IntPersonal per : _personal) {
            if (per.getIdentificador().compareTo(identificador) == 0) {
                return per;
            }
        }
        return null;
    }

    public boolean modificar(IntPersonal persona) {
        IntPersonal original;
        original = buscar(persona.getIdentificador());
        return original.modificar(persona);
    }

     public String generarNominas() {
        String nominas = "";
        for (IntPersonal per : _personal) {
            nominas += per.generarNomina() + "\n";
        }
        return nominas;
    }

    @Override
    public String toString() {
        StringBuilder resultado = new StringBuilder();
        for (IntPersonal per : _personal) {
            resultado.append(per.toString()).append("\n");
        }

        return resultado.toString();
    }
}
