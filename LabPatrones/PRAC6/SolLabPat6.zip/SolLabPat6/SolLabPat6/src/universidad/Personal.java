package universidad;

public abstract class Personal implements IntPersonal {

    private Handler _identificador;
    private Nomina nomina;

    public Personal(Handler _identificador) throws BadFormatException {
        this._identificador = _identificador;
    }

    @Override
    public Handler getIdentificador() {
        return _identificador;
    }

    @Override
    public Nomina getNomina() {
        return nomina;
    }

    public void setNomina(Nomina nomina) {
        this.nomina = nomina;
    }   
    
    @Override
    public abstract boolean modificar(IntPersonal otro);
    
    @Override
    public abstract String generarNomina();

    @Override
    public String toString() {
        return "Personal{" + "_identificador=" + _identificador + ", nomina=" + nomina + '}';
    }
    
    
}
