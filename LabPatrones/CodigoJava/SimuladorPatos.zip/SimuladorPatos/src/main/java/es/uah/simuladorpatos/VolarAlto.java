package es.uah.simuladorpatos;

public class VolarAlto implements IVuelo {

    @Override
    public String volar() {
        return "* Vuelo Alto *";
    }
}
