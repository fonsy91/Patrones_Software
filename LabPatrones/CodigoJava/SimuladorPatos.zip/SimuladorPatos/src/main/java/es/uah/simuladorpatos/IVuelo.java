package es.uah.simuladorpatos;

public interface IVuelo {

    public String volar();
}
