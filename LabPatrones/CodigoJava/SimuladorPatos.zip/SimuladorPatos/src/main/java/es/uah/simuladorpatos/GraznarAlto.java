package es.uah.simuladorpatos;

public class GraznarAlto implements IGraznido {

    @Override
    public String graznar() {
        return "* Grazno Alto *";
    }
}
