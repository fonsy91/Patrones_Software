package es.uah.simuladorpatos;

public class NoGraznar implements IGraznido {

    @Override
    public String graznar() {
        return "* No Grazno *";
    }
}
