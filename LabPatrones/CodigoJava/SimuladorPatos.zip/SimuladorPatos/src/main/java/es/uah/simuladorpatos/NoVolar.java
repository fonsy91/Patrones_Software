package es.uah.simuladorpatos;

public class NoVolar implements IVuelo {

    @Override
    public String volar() {
        return "* No Vuelo *";
    }
}
