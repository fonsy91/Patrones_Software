package es.uah.simuladorpatos;

public interface IGraznido {

    public String graznar();
}
