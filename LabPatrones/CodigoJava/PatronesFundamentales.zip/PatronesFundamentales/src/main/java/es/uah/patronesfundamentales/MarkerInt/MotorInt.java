package es.uah.patronesfundamentales.MarkerInt;

/**
 * Interfaz vacía que representa el marcador o bandera.
 */
public interface MotorInt {

}
