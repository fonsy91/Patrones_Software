package universidad;

public interface IntNomina {

    public int calculaNomina(String tipo);
    
}
