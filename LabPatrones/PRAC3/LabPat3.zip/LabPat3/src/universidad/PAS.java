package universidad;

public class PAS extends Personal {

    private String _seccion;
    private String _cargo;

    public PAS(int identificador, String seccion, String cargo) {
        super(identificador);
        _seccion = seccion;
        _cargo = cargo;
    }

    public String getSeccion() {
        return _seccion;
    }

    public String getCargo() {
        return _cargo;
    }

    @Override
    public String generarNomina() {
        return "Generada nomina de PAS: " + super.getIdentificador();
    }

    @Override
    public boolean modificar(IntPersonal otro) {
        boolean ok = false;
        try {
            if (otro.getIdentificador() == super.getIdentificador()) {
                _seccion = ((PAS) otro).getSeccion();
                _cargo = ((PAS) otro).getCargo();
                ok = true;
            }
        } catch (ClassCastException e) {
            ok = false;
        }
        return ok;
    }

    @Override
    public String toString() {
        return "PAS{" + "_identificador=" + super.getIdentificador() + ", _seccion=" + _seccion + ", _cargo=" + _cargo + '}';
    }
}
