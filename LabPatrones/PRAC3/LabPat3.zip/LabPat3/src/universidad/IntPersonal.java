package universidad;

public interface IntPersonal {

    public int getIdentificador();

    public String generarNomina();

    public boolean modificar(IntPersonal otro);

    @Override
    public String toString();
}
