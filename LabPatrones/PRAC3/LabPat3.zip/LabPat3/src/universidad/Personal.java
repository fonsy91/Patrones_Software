package universidad;

public abstract class Personal implements IntPersonal{

    private int _identificador;

    public Personal(int _identificador) {
        this._identificador = _identificador;
    }

    @Override
    public int getIdentificador() {
        return _identificador;
    }

    @Override
    public abstract boolean modificar(IntPersonal otro);
    
    @Override
    public abstract String generarNomina();
}
