package universidad;

public class PDI extends Personal {

    private String _departamento;
    private String _area;

    public PDI(int identificador, String departamento, String area) {
        super(identificador);
        _departamento = departamento;
        _area = area;
    }

    public String getDepartamento() {
        return _departamento;
    }

    public String getArea() {
        return _area;
    }

    @Override
    public String generarNomina() {
        return "Generada nomina de PDI: " + super.getIdentificador();
    }

    @Override
    public boolean modificar(IntPersonal otro) {
        boolean ok = false;        
        try {
            if (otro.getIdentificador() == super.getIdentificador()) {
                _departamento = ((PDI) otro).getDepartamento();
                _area = ((PDI) otro).getArea();
                ok = true;
            }
        } catch (ClassCastException e) {
            ok = false;
        }
        return ok;
    }

    @Override
    public String toString() {
        return "PDI{" + "_identificador=" + super.getIdentificador() + ", _departamento=" + _departamento + ", _area=" + _area + '}';
    }

}
