package patrones01;

public interface IPago {

    public void cantidad(double importe);
}
