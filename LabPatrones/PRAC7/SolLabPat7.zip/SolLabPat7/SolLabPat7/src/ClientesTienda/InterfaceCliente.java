package ClientesTienda;

public interface InterfaceCliente {

    public String getCIF();

    public String getNombre();

    public String getDireccion();

    @Override
    public String toString();
}
