package ProxyEmpleados;

public interface InterfaceEmpleado {

    public String informacionEmpleado();
}
